# Generated manually for MotorMind financial module hardening.

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("financial", "0003_alter_cashflowentry_options"),
    ]

    operations = [
        migrations.AlterModelOptions(
            name="cashflowentry",
            options={
                "ordering": ["-created_at"],
                "verbose_name": "Lançamento de caixa",
                "verbose_name_plural": "Lançamentos de caixa",
            },
        ),
        migrations.AlterField(
            model_name="expense",
            name="status",
            field=models.CharField(
                choices=[
                    ("pending", "Pendente"),
                    ("paid", "Pago"),
                    ("overdue", "Vencido"),
                    ("canceled", "Cancelado"),
                ],
                default="pending",
                max_length=20,
                verbose_name="Status",
            ),
        ),
        migrations.AlterField(
            model_name="payment",
            name="method",
            field=models.CharField(
                choices=[
                    ("cash", "Dinheiro"),
                    ("pix", "PIX"),
                    ("debit_card", "Cartão de débito"),
                    ("credit_card", "Cartão de crédito"),
                    ("bank_transfer", "Transferência bancária"),
                    ("check", "Cheque"),
                    ("other", "Outro"),
                ],
                max_length=30,
                verbose_name="Forma de pagamento",
            ),
        ),
        migrations.AlterField(
            model_name="receivable",
            name="status",
            field=models.CharField(
                choices=[
                    ("pending", "Pendente"),
                    ("paid", "Pago"),
                    ("overdue", "Vencido"),
                    ("canceled", "Cancelado"),
                ],
                default="pending",
                max_length=20,
                verbose_name="Status",
            ),
        ),
    ]
