# Generated manually for customer full address fields.

from django.core.validators import RegexValidator
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("customers", "0002_alter_customer_document"),
    ]

    operations = [
        migrations.AddField(
            model_name="customer",
            name="zip_code",
            field=models.CharField(
                blank=True,
                help_text="Informe o CEP para preenchimento automático do endereço.",
                max_length=9,
                null=True,
                validators=[
                    RegexValidator(
                        regex=r"^\d{5}-?\d{3}$",
                        message="Informe um CEP válido no formato 00000-000.",
                    )
                ],
                verbose_name="CEP",
            ),
        ),
        migrations.AddField(
            model_name="customer",
            name="street",
            field=models.CharField(
                blank=True,
                max_length=150,
                null=True,
                verbose_name="Logradouro",
            ),
        ),
        migrations.AddField(
            model_name="customer",
            name="number",
            field=models.CharField(
                blank=True,
                max_length=20,
                null=True,
                verbose_name="Número",
            ),
        ),
        migrations.AddField(
            model_name="customer",
            name="complement",
            field=models.CharField(
                blank=True,
                max_length=100,
                null=True,
                verbose_name="Complemento",
            ),
        ),
        migrations.AddField(
            model_name="customer",
            name="neighborhood",
            field=models.CharField(
                blank=True,
                max_length=100,
                null=True,
                verbose_name="Bairro",
            ),
        ),
        migrations.AddField(
            model_name="customer",
            name="city",
            field=models.CharField(
                blank=True,
                max_length=100,
                null=True,
                verbose_name="Cidade",
            ),
        ),
        migrations.AddField(
            model_name="customer",
            name="state",
            field=models.CharField(
                blank=True,
                max_length=2,
                null=True,
                verbose_name="UF",
            ),
        ),
        migrations.AlterField(
            model_name="customer",
            name="address",
            field=models.CharField(
                blank=True,
                help_text="Campo legado preenchido automaticamente a partir dos campos detalhados.",
                max_length=255,
                null=True,
                verbose_name="Endereço completo",
            ),
        ),
    ]
