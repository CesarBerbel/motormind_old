"""
Read-only selectors for account dashboards and profile landing areas.

The atendimento area is a profile-specific operational dashboard. It must read
from customers, vehicles and service_orders without changing data in those apps.
"""

from django.db.models import Count, Q
from django.utils import timezone

from customers.models import Customer, Vehicle
from service_orders.models import ServiceOrder


def get_attendant_dashboard_data(limit=8):
    """
    Return the operational data required by the attendant area.

    The attendant is responsible for customer reception, customer/vehicle
    registration, service order opening and operational follow-up. This selector
    keeps those reads centralized and avoids business logic inside the template.
    """
    today = timezone.localdate()

    active_statuses = [
        ServiceOrder.Status.OPEN,
        ServiceOrder.Status.IN_PROGRESS,
        ServiceOrder.Status.WAITING_PARTS,
        ServiceOrder.Status.WAITING_APPROVAL,
    ]

    service_orders = ServiceOrder.objects.select_related(
        "customer",
        "vehicle",
        "assigned_mechanic",
    )

    open_orders = service_orders.filter(status=ServiceOrder.Status.OPEN)
    waiting_approval_orders = service_orders.filter(
        status=ServiceOrder.Status.WAITING_APPROVAL,
    )
    waiting_parts_orders = service_orders.filter(
        status=ServiceOrder.Status.WAITING_PARTS,
    )
    overdue_orders = service_orders.filter(
        expected_delivery_date__lt=today,
    ).exclude(
        status__in=[
            ServiceOrder.Status.FINISHED,
            ServiceOrder.Status.CANCELED,
        ],
    )

    recent_orders = service_orders.exclude(
        status=ServiceOrder.Status.CANCELED,
    ).order_by(
        "expected_delivery_date",
        "-created_at",
    )[:limit]

    recent_customers = Customer.objects.filter(
        is_active=True,
    ).annotate(
        active_orders_count=Count(
            "service_orders",
            filter=Q(service_orders__status__in=active_statuses),
        )
    ).order_by(
        "-created_at",
    )[:limit]

    return {
        "customers_count": Customer.objects.filter(is_active=True).count(),
        "vehicles_count": Vehicle.objects.filter(is_active=True).count(),
        "open_orders_count": open_orders.count(),
        "waiting_approval_orders_count": waiting_approval_orders.count(),
        "waiting_parts_orders_count": waiting_parts_orders.count(),
        "overdue_orders_count": overdue_orders.count(),
        "recent_orders": recent_orders,
        "recent_customers": recent_customers,
    }


def get_main_dashboard_data(user):
    """
    Return shared counters for the main authenticated dashboard.
    """
    today = timezone.localdate()

    overdue_service_orders_count = (
        ServiceOrder.objects.filter(
            expected_delivery_date__lt=today,
        )
        .exclude(
            status__in=[
                ServiceOrder.Status.FINISHED,
                ServiceOrder.Status.CANCELED,
            ]
        )
        .count()
    )

    open_service_orders_count = (
        ServiceOrder.objects.exclude(
            status__in=[
                ServiceOrder.Status.FINISHED,
                ServiceOrder.Status.CANCELED,
            ]
        ).count()
    )

    assigned_to_me_count = (
        ServiceOrder.objects.filter(
            assigned_mechanic=user,
        )
        .exclude(
            status__in=[
                ServiceOrder.Status.FINISHED,
                ServiceOrder.Status.CANCELED,
            ]
        )
        .count()
    )

    return {
        "overdue_service_orders_count": overdue_service_orders_count,
        "open_service_orders_count": open_service_orders_count,
        "assigned_to_me_count": assigned_to_me_count,
    }
