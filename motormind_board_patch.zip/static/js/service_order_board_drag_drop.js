// Enables drag and drop status updates on the service order board.
// The regular select form remains available as fallback.

function getCookie(name) {
    let cookieValue = null;

    if (document.cookie && document.cookie !== "") {
        const cookies = document.cookie.split(";");

        for (let index = 0; index < cookies.length; index += 1) {
            const cookie = cookies[index].trim();

            if (cookie.substring(0, name.length + 1) === `${name}=`) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }

    return cookieValue;
}

function showDragMessage(message, type) {
    const messageContainer = document.getElementById("dragDropMessage");

    if (!messageContainer) {
        return;
    }

    messageContainer.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
        </div>
    `;
}

function updateColumnCounters() {
    const columns = document.querySelectorAll(".service-order-dropzone");

    columns.forEach(function (column) {
        const status = column.dataset.status;
        const counter = document.querySelector(
            `.service-order-column-counter[data-status="${status}"]`
        );

        if (!counter) {
            return;
        }

        const cards = column.querySelectorAll(".service-order-card");

        counter.textContent = cards.length;
    });
}

function updateEmptyColumnMessages() {
    const columns = document.querySelectorAll(".service-order-dropzone");

    columns.forEach(function (column) {
        const cards = column.querySelectorAll(".service-order-card");
        const emptyMessage = column.querySelector(".service-order-empty-message");

        if (!emptyMessage) {
            return;
        }

        if (cards.length === 0) {
            emptyMessage.classList.remove("d-none");
        } else {
            emptyMessage.classList.add("d-none");
        }
    });
}

function updateCardVisualStatus(card, status, statusLabel) {
    const statusBadge = card.querySelector(".service-order-status-badge");
    const statusSelect = card.querySelector('select[name="status"]');

    card.dataset.status = status;
    card.classList.add("was-updated");

    if (statusBadge) {
        statusBadge.textContent = statusLabel;
        statusBadge.className = "badge text-bg-secondary service-order-status-badge";
    }

    if (statusSelect) {
        statusSelect.value = status;
    }

    window.setTimeout(function () {
        card.classList.remove("was-updated");
    }, 800);
}

function updateServiceOrderStatus(status, updateUrl) {
    const csrfToken = getCookie("csrftoken");
    const formData = new FormData();

    formData.append("status", status);

    return fetch(updateUrl, {
        method: "POST",
        headers: {
            "X-CSRFToken": csrfToken,
            "X-Requested-With": "XMLHttpRequest"
        },
        body: formData
    }).then(function (response) {
        if (!response.ok) {
            return response.json().then(function (data) {
                throw new Error(data.message || "Não foi possível atualizar o status.");
            });
        }

        return response.json();
    });
}

document.addEventListener("DOMContentLoaded", function () {
    const cards = document.querySelectorAll(".service-order-card");
    const columns = document.querySelectorAll(".service-order-dropzone");

    updateColumnCounters();
    updateEmptyColumnMessages();

    cards.forEach(function (card) {
        card.addEventListener("dragstart", function (event) {
            event.dataTransfer.setData("text/plain", card.dataset.orderId);
            card.classList.add("is-dragging");
        });

        card.addEventListener("dragend", function () {
            card.classList.remove("is-dragging");
        });
    });

    columns.forEach(function (column) {
        column.addEventListener("dragover", function (event) {
            event.preventDefault();
            column.classList.add("is-drag-over");
        });

        column.addEventListener("dragleave", function () {
            column.classList.remove("is-drag-over");
        });

        column.addEventListener("drop", function (event) {
            event.preventDefault();
            column.classList.remove("is-drag-over");

            const orderId = event.dataTransfer.getData("text/plain");
            const card = document.querySelector(`[data-order-id="${orderId}"]`);

            if (!card) {
                return;
            }

            const newStatus = column.dataset.status;
            const currentStatus = card.dataset.status;
            const updateUrl = card.dataset.updateUrl;

            if (newStatus === currentStatus) {
                return;
            }

            updateServiceOrderStatus(newStatus, updateUrl)
                .then(function (data) {
                    column.appendChild(card);
                    updateCardVisualStatus(card, data.status, data.status_label);
                    updateColumnCounters();
                    updateEmptyColumnMessages();
                    showDragMessage(data.message || "Status atualizado com sucesso.", "success");
                })
                .catch(function (error) {
                    updateColumnCounters();
                    updateEmptyColumnMessages();
                    showDragMessage(error.message, "danger");
                });
        });
    });
});
